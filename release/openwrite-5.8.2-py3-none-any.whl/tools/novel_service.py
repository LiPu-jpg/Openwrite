"""Unified application service for creator-facing novel operations.

CLI, Studio and long-session agents should enter novel workflows through this
surface.  Legacy CLI executors remain implementation adapters for now, while
input normalization, canonical packet assembly and result semantics live here.
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import re
import tempfile
from collections.abc import Callable
from dataclasses import asdict, is_dataclass
from pathlib import Path
from threading import Lock
from typing import Any, cast

import yaml


class NovelServiceError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        code: str = "OPERATION_FAILED",
        details: dict[str, Any] | None = None,
    ):
        super().__init__(message)
        self.code = code
        self.details = details or {}


class NovelApplicationService:
    """One application boundary shared by CLI, Studio and agents."""

    @classmethod
    def initialize(
        cls,
        project_root: Path,
        novel_id: str,
        title: str = "",
        *,
        template: str = "default",
        author: str = "",
        language: str = "zh-CN",
    ) -> NovelApplicationService:
        from tools.init_project import init_project

        try:
            init_project(Path(project_root), novel_id, title, template=template, author=author, language=language)
        except Exception as exc:
            raise NovelServiceError(f"初始化失败: {exc}", code="INVALID_INPUT") from exc
        return cls(Path(project_root))

    def __init__(
        self,
        project_root: Path,
        *,
        writer_executor: Callable[[Path, dict[str, Any]], dict[str, Any]] | None = None,
        review_executor: Callable[[Path, dict[str, Any]], dict[str, Any]] | None = None,
        source_executor: Callable[[Path, dict[str, Any]], dict[str, Any]] | None = None,
        task_lock: Lock | None = None,
    ):
        self.project_root = Path(project_root).resolve()
        self.config_path = self.project_root / "novel_config.yaml"
        self.config = self._load_config()
        self.novel_id = str(self.config.get("novel_id") or "")
        if not self.novel_id:
            raise NovelServiceError("novel_config.yaml 缺少 novel_id", code="INVALID_PROJECT")
        self.novel_root = self.project_root / "data" / "novels" / self.novel_id
        self._writer_executor = writer_executor
        self._review_executor = review_executor
        self._source_executor = source_executor
        self._task_lock = task_lock or Lock()

    def refresh(self) -> None:
        self.config = self._load_config()
        self.novel_id = str(self.config.get("novel_id") or self.novel_id)
        self.novel_root = self.project_root / "data" / "novels" / self.novel_id

    def sync_status(self) -> dict[str, Any]:
        from tools.source_sync import collect_sync_status

        return cast(
            dict[str, Any],
            collect_sync_status(self.project_root, self.novel_id),
        )

    def sync(self) -> dict[str, Any]:
        from tools.source_sync import run_sync

        before = self.sync_status()
        run_sync(self.project_root, self.novel_id)
        return {"before": before, "after": self.sync_status()}

    def workspace_snapshot(self) -> dict[str, Any]:
        snapshot: dict[str, Any] = self.workspace_state().to_dict()
        return snapshot

    def workspace_state(self) -> Any:
        from tools.novel_workspace import build_workspace_snapshot

        self.refresh()
        return build_workspace_snapshot(self.project_root, self.config)

    def focus_snapshot(self) -> dict[str, Any]:
        from tools.novel_workspace import load_creative_focus

        return asdict(load_creative_focus(self.project_root, self.novel_id))

    def render_focus(self) -> str:
        from tools.novel_workspace import load_creative_focus, render_creative_focus

        rendered: str = render_creative_focus(load_creative_focus(self.project_root, self.novel_id))
        return rendered

    def update_focus(
        self,
        *,
        goal: str,
        must_keep: list[str] | None = None,
        must_avoid: list[str] | None = None,
        notes: list[str] | None = None,
    ) -> Path:
        from tools.novel_workspace import save_creative_focus

        clean_goal = str(goal or "").strip()
        if not clean_goal:
            raise NovelServiceError("当前阶段目标不能为空", code="INVALID_INPUT")
        path: Path = save_creative_focus(
            self.project_root,
            self.novel_id,
            goal=clean_goal,
            must_keep=must_keep or [],
            must_avoid=must_avoid or [],
            notes=notes or [],
        )
        return path

    def clear_focus(self) -> Path:
        from tools.novel_workspace import (
            CreativeFocus,
            current_focus_path,
            render_creative_focus,
        )

        path: Path = current_focus_path(self.project_root, self.novel_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(render_creative_focus(CreativeFocus()), encoding="utf-8")
        return path

    def import_book(
        self,
        source: Path,
        *,
        arc_id: str | None = None,
        start_number: int | None = None,
        force: bool = False,
    ) -> dict[str, Any]:
        from tools.manuscript_acceptance import ManuscriptAcceptanceService
        from tools.novel_workspace import import_manuscript, update_project_progress

        target_arc = str(arc_id or self.config.get("current_arc") or "arc_001")
        if not re.fullmatch(r"arc_\d+", target_arc):
            raise NovelServiceError("篇 ID 必须形如 arc_001", code="INVALID_INPUT")
        acceptance_service = ManuscriptAcceptanceService(self.project_root, self.novel_id)
        accepted_before = {
            str(item.get("chapter_id") or ""): str(item.get("accepted_revision") or "")
            for item in acceptance_service.inspect().get("chapters", [])
            if isinstance(item, dict)
        }
        try:
            imported = import_manuscript(
                self.project_root,
                self.novel_id,
                Path(source),
                arc_id=target_arc,
                start_number=start_number,
                force=force,
            )
        except FileExistsError as exc:
            raise NovelServiceError(str(exc), code="CONFLICT") from exc
        except (OSError, ValueError) as exc:
            raise NovelServiceError(str(exc), code="INVALID_INPUT") from exc
        next_number = self._chapter_number(imported[-1].chapter_id) + 1
        next_chapter = f"ch_{next_number:03d}"
        update_project_progress(
            self.project_root,
            current_chapter=next_chapter,
            current_arc=target_arc,
        )
        self.refresh()
        earliest = min(imported, key=lambda item: self._chapter_number(item.chapter_id))
        acceptance = acceptance_service.start_acceptance(
            earliest.chapter_id,
            source="import",
            expected_previous_revision=accepted_before.get(earliest.chapter_id, ""),
        )
        return {
            "arc_id": target_arc,
            "next_chapter": next_chapter,
            "writing_units": sum(item.writing_units for item in imported),
            "acceptance": acceptance,
            "imported": [
                {
                    "chapter_id": item.chapter_id,
                    "title": item.title,
                    "writing_units": item.writing_units,
                }
                for item in imported
            ],
        }

    def export_book(
        self,
        output: Path,
        *,
        format_name: str = "md",
        purpose: str = "backup",
        preflight_revision: str = "",
        title: str = "",
        author: str = "",
        language: str = "zh-CN",
        cover: Path | None = None,
    ) -> Path:
        from tools.export_preflight import ExportPreflightError, ExportPreflightService
        from tools.novel_workspace import export_manuscript
        from tools.project_lock import ProjectBusyError, ProjectWriteLock

        preflight = ExportPreflightService(self.project_root, self.novel_id)
        destination = Path(output)
        destination.parent.mkdir(parents=True, exist_ok=True)
        descriptor, staged_name = tempfile.mkstemp(
            prefix=f".{destination.name}.",
            suffix=".exporting",
            dir=destination.parent,
        )
        os.close(descriptor)
        staged = Path(staged_name)
        previous = staged.with_name(staged.name + ".previous")
        committed = False
        try:
            destination_sha = self._export_file_revision(destination)
            with ProjectWriteLock(
                self.project_root,
                self.novel_id,
                operation=f"export:{format_name}:{purpose}",
            ):
                checked = preflight.require_exportable(
                    format_name=format_name,
                    purpose=purpose,
                    expected_revision=preflight_revision,
                )
                path: Path = export_manuscript(
                    self.project_root,
                    self.novel_id,
                    staged,
                    format_name=format_name,
                    title=title or str(checked["metadata"].get("title") or ""),
                    author=author or str(checked["metadata"].get("author") or ""),
                    language=language or str(checked["metadata"].get("language") or "zh-CN"),
                    cover=cover,
                )
                preflight.validate_output(path, format_name=format_name)
                current = preflight.inspect(format_name=format_name, purpose=purpose)
                if current["preflight_revision"] != checked["preflight_revision"]:
                    raise ExportPreflightError(
                        "导出期间项目内容已经变化，请重新检查",
                        code="EXPORT_PREFLIGHT_CHANGED",
                        details={"preflight": current},
                    )
                self._prepare_export_destination(
                    destination,
                    previous,
                    expected_destination_sha=destination_sha,
                )
                current = preflight.inspect(format_name=format_name, purpose=purpose)
                if current["preflight_revision"] != checked["preflight_revision"]:
                    raise ExportPreflightError(
                        "导出发布期间项目内容已经变化，请重新检查",
                        code="EXPORT_PREFLIGHT_CHANGED",
                        details={"preflight": current},
                    )
                self._publish_export(staged, destination)
                committed = True
                self._best_effort_unlink(previous)
                return destination
        except ExportPreflightError as exc:
            raise NovelServiceError(
                str(exc),
                code=exc.code,
                details=exc.details,
            ) from exc
        except ProjectBusyError as exc:
            raise NovelServiceError(str(exc), code="PROJECT_BUSY") from exc
        except (OSError, ValueError) as exc:
            raise NovelServiceError(str(exc), code="INVALID_INPUT") from exc
        finally:
            recovery_error = None
            if not committed:
                recovery_error = self._restore_export_destination(destination, previous)
            self._best_effort_unlink(staged)
            if recovery_error is not None:
                raise recovery_error

    @staticmethod
    def _export_file_revision(path: Path) -> str:
        candidate = Path(path)
        if not candidate.exists():
            return "sha256:missing"
        if candidate.is_symlink() or not candidate.is_file():
            raise NovelServiceError(
                "导出目标必须是普通文件",
                code="INVALID_EXPORT_OUTPUT",
            )
        try:
            content = candidate.read_bytes()
        except OSError as exc:
            raise NovelServiceError(
                "导出目标在检查期间发生变化",
                code="EXPORT_OUTPUT_CHANGED",
            ) from exc
        return "sha256:" + hashlib.sha256(content).hexdigest()

    @classmethod
    def _prepare_export_destination(
        cls,
        destination: Path,
        previous: Path,
        *,
        expected_destination_sha: str,
    ) -> None:
        if expected_destination_sha == "sha256:missing":
            return
        try:
            os.replace(destination, previous)
        except FileNotFoundError as exc:
            raise NovelServiceError(
                "导出目标已由其他进程删除，请重新导出",
                code="EXPORT_OUTPUT_CHANGED",
            ) from exc
        current_sha = cls._export_file_revision(previous)
        if current_sha != expected_destination_sha:
            raise NovelServiceError(
                "导出目标已由其他进程修改，请重新导出",
                code="EXPORT_OUTPUT_CHANGED",
                details={"expected": expected_destination_sha, "current": current_sha},
            )

    @staticmethod
    def _publish_export(staged: Path, destination: Path) -> None:
        try:
            os.link(staged, destination)
        except FileExistsError as exc:
            raise NovelServiceError(
                "导出目标已由其他进程创建，请重新导出",
                code="EXPORT_OUTPUT_CHANGED",
            ) from exc

    @staticmethod
    def _restore_export_destination(destination: Path, previous: Path) -> NovelServiceError | None:
        if not previous.exists():
            return None
        details = {
            "destination": str(destination),
            "recovery_path": str(previous),
        }
        if destination.exists():
            return NovelServiceError(
                "导出目标已被其他进程占用；原文件保留在恢复路径",
                code="EXPORT_OUTPUT_CHANGED",
                details=details,
            )
        try:
            os.link(previous, destination)
        except FileExistsError:
            return NovelServiceError(
                "导出目标已被其他进程创建；原文件保留在恢复路径",
                code="EXPORT_OUTPUT_CHANGED",
                details=details,
            )
        except OSError as exc:
            return NovelServiceError(
                "导出失败且原文件无法自动恢复；请使用恢复路径中的副本",
                code="EXPORT_OUTPUT_RECOVERY_REQUIRED",
                details={**details, "reason": str(exc)},
            )
        try:
            previous.unlink()
        except OSError as exc:
            return NovelServiceError(
                "原导出已恢复，但恢复副本未能清理",
                code="EXPORT_OUTPUT_RECOVERY_REQUIRED",
                details={**details, "reason": str(exc)},
            )
        return None

    @staticmethod
    def _best_effort_unlink(path: Path) -> None:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass

    def export_preflight(
        self,
        *,
        format_name: str = "md",
        purpose: str = "backup",
    ) -> dict[str, Any]:
        from tools.export_preflight import ExportPreflightError, ExportPreflightService

        try:
            return ExportPreflightService(self.project_root, self.novel_id).inspect(
                format_name=format_name,
                purpose=purpose,
            )
        except ExportPreflightError as exc:
            raise NovelServiceError(str(exc), code=exc.code, details=exc.details) from exc

    def market_radar(
        self,
        *,
        platforms: list[str] | None = None,
        top_n: int = 5,
    ) -> dict[str, Any]:
        """Run novel-market research behind the application boundary."""
        from tools.agent import AgentContext
        from tools.llm import LLMClient, LLMConfig
        from tools.radar import RadarAgent

        if top_n < 1 or top_n > 50:
            raise NovelServiceError("推荐数量必须在 1 到 50 之间", code="INVALID_INPUT")
        try:
            llm_config = LLMConfig.from_env()
            agent = RadarAgent(
                AgentContext(
                    LLMClient(llm_config),
                    llm_config.model,
                    str(self.project_root),
                )
            )
            result = asyncio.run(agent.scan_market(platforms=platforms, top_n=top_n))
        except Exception as exc:
            raise NovelServiceError(f"市场分析失败: {exc}") from exc
        return {
            "recommendations": [
                {
                    "confidence": float(item.confidence),
                    "platform": str(item.platform),
                    "genre": str(item.genre),
                    "concept": str(item.concept),
                    "reasoning": str(item.reasoning),
                    "benchmarks": list(item.benchmarks or []),
                }
                for item in result.platform_recommendations
            ],
            "trends": list(result.trends or []),
        }

    def create_document(
        self,
        *,
        kind: str,
        name: str,
        description: str = "",
        content: str = "",
    ) -> Path:
        from tools.shared_documents import (
            normalize_character_document,
            normalize_world_entity_document,
        )

        if kind not in {"character", "world"}:
            raise NovelServiceError("仅支持创建人物或世界设定文档", code="INVALID_INPUT")
        clean_name = str(name or "").strip()
        if not clean_name or len(clean_name) > 80 or any(char in clean_name for char in "/\\\x00"):
            raise NovelServiceError(
                "名称不能为空、不能超过 80 字或包含路径分隔符",
                code="INVALID_INPUT",
            )
        safe_name = re.sub(r"[^\w\u3400-\u9fff.-]+", "_", clean_name).strip("._")
        if not safe_name:
            raise NovelServiceError("名称无效", code="INVALID_INPUT")
        if kind == "character":
            path = self.novel_root / "src" / "characters" / f"{safe_name}.md"
            content = normalize_character_document(
                content,
                fallback_id=safe_name,
                fallback_name=clean_name,
                fallback_description=description,
            )
        else:
            path = self.novel_root / "src" / "world" / "entities" / f"{safe_name}.md"
            content = normalize_world_entity_document(
                content,
                fallback_id=safe_name,
                fallback_name=clean_name,
                fallback_summary=description,
            )
        if path.exists():
            raise NovelServiceError("同名文档已存在", code="CONFLICT")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def context_preview(self, chapter_id: str = "next") -> dict[str, Any]:
        from tools.context_builder import ContextBuilder
        from tools.context_manifest import build_context_manifest
        from tools.context_protection import ContextBudgetError

        target = self.resolve_chapter_id(chapter_id)
        try:
            packet = self.assemble_packet(target)
            generation = ContextBuilder(self.project_root, self.novel_id).build_generation_context(
                target
            )
        except ContextBudgetError as exc:
            raise NovelServiceError(str(exc), code=exc.code, details=exc.details) from exc
        manifest_packet = {
            **packet,
            "character_states": generation.character_states,
            "semantic_references": generation.semantic_references,
            "scene_context": getattr(generation, "scene_context", {}),
        }
        manifest = build_context_manifest(self.novel_root, manifest_packet)
        manifest["generation_budget"] = dict(getattr(generation, "compression", {}) or {})
        manifest["retrieval"] = dict(generation.semantic_retrieval)
        result = {
            "chapter_id": target,
            "target_words": int(packet.get("target_words") or 0),
            "characters": list((packet.get("character_documents") or {}).keys()),
            "markdown": str(packet.get("outline") or ""),
            "character_states": generation.character_states,
            "semantic_references": generation.semantic_references,
            "semantic_retrieval": generation.semantic_retrieval,
            "manifest": manifest,
            "packet": packet,
        }
        scene_context = getattr(generation, "scene_context", {})
        if scene_context:
            result["scene_context"] = scene_context
        return result

    def assemble_packet(self, chapter_id: str) -> dict[str, Any]:
        from tools.chapter_assembler import ChapterAssemblerV2
        from tools.context_protection import ContextBudgetError

        style_id = str(self.config.get("style_id") or self.novel_id)
        try:
            packet = ChapterAssemblerV2(
                project_root=self.project_root,
                novel_id=self.novel_id,
                style_id=style_id,
            ).assemble(chapter_id)
        except ContextBudgetError as exc:
            raise NovelServiceError(str(exc), code=exc.code, details=exc.details) from exc
        if is_dataclass(packet):
            payload = asdict(cast(Any, packet))
        elif isinstance(packet, dict):
            payload = dict(packet)
        else:
            payload = {}
            for key in (
                "novel_id",
                "chapter_id",
                "target_words",
                "author_intent",
                "creative_focus",
                "core_documents",
                "story_background",
                "previous_chapter_content",
                "current_state",
                "ledger",
                "relationships",
                "style_documents",
                "character_documents",
                "setting_documents",
                "concept_documents",
                "continuity_documents",
                "prompt_sections",
                "foundation",
            ):
                value = getattr(packet, key, None)
                if value not in (None, ""):
                    payload[key] = value
        if hasattr(packet, "to_markdown"):
            payload["outline"] = str(packet.to_markdown())
        from tools.context_manifest import build_context_manifest

        payload["context_manifest"] = build_context_manifest(self.novel_root, payload)
        return payload

    def write_chapter(self, payload: dict[str, Any]) -> dict[str, Any]:
        chapter_id = self.resolve_chapter_id(str(payload.get("chapter_id") or "next"))
        from tools.manuscript_acceptance import (
            ManuscriptAcceptanceError,
            ManuscriptAcceptanceService,
        )

        acceptance = ManuscriptAcceptanceService(self.project_root, self.novel_id)
        try:
            acceptance.require_current(chapter_id)
        except ManuscriptAcceptanceError as exc:
            raise NovelServiceError(str(exc), code=exc.code, details=exc.details) from exc
        if any(
            path.is_file()
            for path in (self.novel_root / "data" / "manuscript").glob(f"**/{chapter_id}.md")
        ):
            raise NovelServiceError(
                "目标章节已有正文，请通过修订或版本恢复修改",
                code="CHAPTER_ALREADY_EXISTS",
            )
        args = dict(payload)
        args["chapter_id"] = chapter_id
        args.setdefault("context_packet", self.assemble_packet(chapter_id))
        args["guidance"] = str(args.get("guidance") or "").strip()
        args["target_words"] = self._positive_int(args.get("target_words"))
        temperature = args.get("temperature")
        args["temperature"] = float(
            0.7 if temperature is None or temperature == "" else temperature
        )
        executor = self._writer_executor or self._default_writer_executor
        if not self._task_lock.acquire(blocking=False):
            raise NovelServiceError("已有写作或审稿任务正在运行", code="PROJECT_BUSY")
        try:
            result = executor(self.project_root, args)
        finally:
            self._task_lock.release()
        self._ensure_ok(result, fallback="写作失败")
        if self._writer_executor is not None:
            self._record_write_lifecycle(chapter_id, result)
        from tools.operation_trace import summarize_context_packet

        result["_operation_trace_context"] = summarize_context_packet(
            cast(dict[str, Any], args["context_packet"])
        )
        return result

    def review_chapter(
        self,
        chapter_id: str,
        *,
        strict: bool = False,
        dimensions: list[int] | None = None,
        task_phase: Callable[[str, str], None] | None = None,
        cancel_requested: Callable[[], bool] | None = None,
    ) -> dict[str, Any]:
        target = self.resolve_chapter_id(chapter_id, latest=True)
        executor = self._review_executor or self._default_review_executor
        if not self._task_lock.acquire(blocking=False):
            raise NovelServiceError("已有写作或审稿任务正在运行", code="PROJECT_BUSY")
        try:
            if self._review_executor is None:
                args: dict[str, Any] = {
                    "chapter_id": target,
                    "strict": bool(strict),
                    "dimensions": list(dimensions) if dimensions is not None else None,
                }
                if task_phase is not None:
                    args["_task_phase"] = task_phase
                if cancel_requested is not None:
                    args["_cancel_requested"] = cancel_requested
                result = executor(self.project_root, args)
            else:
                from tools.project_lock import ProjectBusyError, ProjectWriteLock

                try:
                    with ProjectWriteLock(
                        self.project_root,
                        self.novel_id,
                        operation=f"review:{target}",
                    ):
                        result = executor(
                            self.project_root,
                            {
                                "chapter_id": target,
                                "strict": bool(strict),
                                "dimensions": (
                                    list(dimensions) if dimensions is not None else None
                                ),
                            },
                        )
                except ProjectBusyError as exc:
                    raise NovelServiceError(str(exc), code="PROJECT_BUSY") from exc
        finally:
            self._task_lock.release()
        self._ensure_ok(result, fallback="审稿失败")
        if self._review_executor is not None:
            from tools.review_store import ReviewStore, validate_review_v2_record

            # Validate before persistence. A present review_v2 key is
            # canonical data; malformed values must not become artifacts that
            # later readers could interpret through the legacy adapter.
            if isinstance(result, dict) and "review_v2" in result:
                try:
                    validate_review_v2_record(result)
                except ValueError as exc:
                    raise NovelServiceError(
                        f"评审 v2 契约校验失败: {exc}", code="CONTRACT_INVALID"
                    ) from exc

            store = ReviewStore(self.project_root, self.novel_id)
            store.save(target, result)
            persisted = store.load(target)
            if isinstance(persisted, dict):
                persisted_v2 = persisted.get("review_v2")
                result = {
                    **result,
                    "source_revision": persisted.get("source_revision", ""),
                    "reviewed_at": persisted.get("reviewed_at", ""),
                    "issue_delta": persisted.get("issue_delta", result.get("issue_delta", {})),
                }
                if isinstance(persisted_v2, dict) and persisted_v2:
                    result["review_v2"] = persisted_v2
            self._record_review_lifecycle(target, result)
        return result

    def multi_write(self, payload: dict[str, Any]) -> dict[str, Any]:
        from tools.chapter_pipeline import execute_multi_agent_chapter
        from tools.manuscript_acceptance import (
            ManuscriptAcceptanceError,
            ManuscriptAcceptanceService,
        )

        args = dict(payload)
        args["chapter_id"] = self.resolve_chapter_id(str(args.get("chapter_id") or "next"))
        try:
            ManuscriptAcceptanceService(self.project_root, self.novel_id).require_current(
                args["chapter_id"]
            )
        except ManuscriptAcceptanceError as exc:
            raise NovelServiceError(str(exc), code=exc.code, details=exc.details) from exc
        if any(
            path.is_file()
            for path in (self.novel_root / "data" / "manuscript").glob(
                f"**/{args['chapter_id']}.md"
            )
        ):
            raise NovelServiceError(
                "目标章节已有正文，请通过修订或版本恢复修改",
                code="CHAPTER_ALREADY_EXISTS",
            )
        if not self._task_lock.acquire(blocking=False):
            raise NovelServiceError("已有写作或审稿任务正在运行", code="PROJECT_BUSY")
        try:
            result = execute_multi_agent_chapter(self.project_root, args)
        finally:
            self._task_lock.release()
        self._ensure_ok(result, fallback="多 Agent 写作失败")
        return result

    def continuity(self) -> dict[str, Any]:
        from tools.foreshadowing_manager import ForeshadowingDAGManager
        from tools.truth_manager import TruthFilesManager
        from tools.workflow_scheduler import WorkflowScheduler
        from tools.world_query import get_relations_topology

        truth = TruthFilesManager(self.project_root, self.novel_id).load_truth_files()
        manager = ForeshadowingDAGManager(self.project_root, self.novel_id)
        pending = manager.get_pending_nodes(min_weight=1)
        valid, validation_errors = manager.validate_dag()
        workflows = []
        for workflow in WorkflowScheduler(self.project_root, self.novel_id).list_active_workflows():
            workflows.append(
                {
                    "chapter_id": workflow.chapter_id,
                    "current_stage": workflow.current_stage,
                    "error": workflow.error,
                    "stages": [
                        {
                            "name": stage.name,
                            "status": stage.status,
                            "message": stage.message,
                        }
                        for stage in workflow.stages
                    ],
                }
            )
        return {
            "truth": {
                "current_state": truth.current_state,
                "ledger": truth.ledger,
                "relationships": truth.relationships,
            },
            "foreshadowing": {
                "nodes": [node.model_dump() for node in pending],
                **manager.get_statistics(),
            },
            "foreshadowing_validation": {
                "valid": valid,
                "errors": validation_errors,
            },
            "relationship_graph": get_relations_topology(
                self.novel_id, project_root=self.project_root
            ),
            "workflows": workflows,
        }

    def manage_foreshadowing(self, payload: dict[str, Any]) -> dict[str, Any]:
        from tools.foreshadowing_manager import ForeshadowingDAGManager
        from tools.mutation_summary import MISSING_VALUE, build_mutation_summary
        from tools.revision_service import RevisionService

        manager = ForeshadowingDAGManager(self.project_root, self.novel_id)
        action = str(payload.get("action") or "create")
        node_id = str(payload.get("node_id") or "").strip()
        if not node_id:
            raise NovelServiceError("伏笔 ID 不能为空", code="INVALID_INPUT")
        before_node = manager.get_node(node_id)
        before_text = (
            manager.dag_file.read_text(encoding="utf-8") if manager.dag_file.exists() else ""
        )
        if action == "create":
            created = manager.create_node(
                node_id=node_id,
                content=str(payload.get("content") or "").strip(),
                weight=self._positive_int(payload.get("weight")) or 5,
                layer=str(payload.get("layer") or "支线"),
                created_at=str(payload.get("created_at") or ""),
                target_chapter=str(payload.get("target_chapter") or "") or None,
            )
            if not created:
                raise NovelServiceError(f"伏笔节点已存在: {node_id}", code="CONFLICT")
            result = {"node_id": node_id, "status": "created"}
        elif action == "update":
            status = str(payload.get("status") or "").strip()
            if not manager.update_node_status(node_id, status):
                raise NovelServiceError(f"伏笔节点不存在: {node_id}", code="NOT_FOUND")
            result = {"node_id": node_id, "status": status}
        else:
            raise NovelServiceError("未知伏笔操作", code="INVALID_INPUT")
        after_node = manager.get_node(node_id)
        after_text = manager.dag_file.read_text(encoding="utf-8")
        mutation_summary = build_mutation_summary(
            operation=f"foreshadowing.{action}",
            entity_kind="foreshadowing",
            entity_id=node_id,
            path="data/foreshadowing/dag.yaml",
            before=(MISSING_VALUE if before_node is None else before_node.model_dump(mode="json")),
            after=(MISSING_VALUE if after_node is None else after_node.model_dump(mode="json")),
            source_revision=("" if not before_text else RevisionService.fingerprint(before_text)),
            result_revision=RevisionService.fingerprint(after_text),
            field_prefix="node",
            flatten=False,
        )
        return {
            "result": result,
            "continuity": self.continuity(),
            "mutation_summary": mutation_summary,
        }

    def extract_source(
        self,
        *,
        source_id: str,
        source_file: Path,
        focus: str = "style",
        chunk_size: int = 30000,
    ) -> dict[str, Any]:
        source_id = self._validate_source_id(source_id)
        source_file = Path(source_file)
        if focus not in {"style", "setting"}:
            raise NovelServiceError("提取类型必须是 style 或 setting", code="INVALID_INPUT")
        if not source_file.is_file():
            raise NovelServiceError(f"来源文本不存在: {source_file}", code="NOT_FOUND")
        if chunk_size <= 0:
            raise NovelServiceError("分块字数必须大于 0", code="INVALID_INPUT")
        executor = self._source_executor or self._default_source_executor
        payload = {
            "source_id": source_id,
            "source_file": str(source_file),
            "focus": focus,
            "chunk_size": chunk_size,
            "content": source_file.read_text(encoding="utf-8"),
        }
        try:
            result = executor(self.project_root, payload)
        except NovelServiceError:
            raise
        except Exception as exc:
            raise NovelServiceError(f"来源提取失败: {exc}") from exc
        self._ensure_ok(result, fallback="来源提取失败")
        return result

    def review_source(self, source_id: str) -> dict[str, Any]:
        from tools.source_pack import SourcePackService

        source_id = self._validate_source_id(source_id)
        self._require_source_pack(source_id)
        try:
            source_pack = SourcePackService(self.project_root, self.novel_id)
            report = source_pack.render_review(source_id)
            metadata = source_pack.review_metadata(source_id)
        except Exception as exc:
            raise NovelServiceError(f"来源审阅失败: {exc}") from exc
        return {
            "ok": True,
            "source_id": source_id,
            "review_report": report,
            "review_metadata": metadata,
        }

    def prepare_source_analysis_v2(
        self,
        *,
        source_id: str,
        content: str,
        relative_name: str,
        focus: list[str] | None = None,
        input_budget_tokens: int = 12000,
    ) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        source_id = self._validate_source_id(source_id)
        try:
            return SourcePackService(self.project_root, self.novel_id).prepare_v2(
                source_id,
                content,
                relative_name=relative_name,
                focus=focus,
                input_budget_tokens=input_budget_tokens,
            )
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def analyze_source_v2(self, source_id: str) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        source_id = self._validate_source_id(source_id)
        try:
            return SourcePackService(self.project_root, self.novel_id).analyze_v2(source_id)
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def source_status_v2(self, source_id: str) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        source_id = self._validate_source_id(source_id)
        try:
            return SourcePackService(self.project_root, self.novel_id).status_v2(source_id)
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def retry_source_v2(self, source_id: str, chunk_id: str) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        source_id = self._validate_source_id(source_id)
        try:
            return SourcePackService(self.project_root, self.novel_id).retry_v2(source_id, chunk_id)
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def synthesize_sources_v2(self, source_ids: list[str]) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        clean_ids = [self._validate_source_id(source_id) for source_id in source_ids]
        try:
            return SourcePackService(self.project_root, self.novel_id).synthesize_v2(clean_ids)
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def source_profile_v2(self, profile_id: str) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        try:
            return SourcePackService(self.project_root, self.novel_id).profile_v2(profile_id)
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def preview_source_promotion_v2(self, profile_id: str, target: str) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        try:
            return SourcePackService(self.project_root, self.novel_id).preview_promotion_v2(
                profile_id, target
            )
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def apply_source_promotion_v2(self, preview_id: str, *, confirm: bool) -> dict[str, Any]:
        from tools.source_analysis import SourceAnalysisError
        from tools.source_pack import SourcePackService

        try:
            return SourcePackService(self.project_root, self.novel_id).apply_promotion_v2(
                preview_id, confirm=confirm
            )
        except SourceAnalysisError as exc:
            raise NovelServiceError(str(exc), code=exc.code) from exc

    def promote_source(self, source_id: str, target: str = "all") -> dict[str, Any]:
        from tools.source_pack import SourcePackService

        source_id = self._validate_source_id(source_id)
        if target not in {"style", "setting", "world", "all"}:
            raise NovelServiceError("晋升目标无效", code="INVALID_INPUT")
        self._require_source_pack(source_id)
        source_pack = SourcePackService(self.project_root, self.novel_id)
        readiness = source_pack.promotion_readiness(source_id, target)
        if not readiness["ready"]:
            missing = "、".join(readiness["missing_items"])
            raise NovelServiceError(
                f"来源包尚不可晋升到 {target}，缺少: {missing}",
                code="SOURCE_INCOMPLETE",
            )
        try:
            promoted = source_pack.promote(source_id, target)
        except Exception as exc:
            raise NovelServiceError(f"来源晋升失败: {exc}") from exc
        self.refresh()
        return {
            "ok": True,
            "source_id": source_id,
            "target": target,
            "promoted": promoted,
        }

    def synthesize_style(self, source_id: str) -> dict[str, Any]:
        from tools.style_synthesizer import synthesize_style_document

        source_id = self._validate_source_id(source_id)
        try:
            result = cast(
                dict[str, Any],
                synthesize_style_document(
                    self.project_root,
                    self.novel_id,
                    source_id,
                ),
            )
        except Exception as exc:
            raise NovelServiceError(f"风格合成失败: {exc}") from exc
        return {**result, "ok": True, "source_id": source_id}

    def resolve_chapter_id(self, chapter_id: str, *, latest: bool = False) -> str:
        value = str(chapter_id or "").strip()
        manuscript_root = self.novel_root / "data" / "manuscript"
        chapter_ids = {
            path.stem
            for path in manuscript_root.glob("**/ch_*.md")
            if re.fullmatch(r"ch_\d+", path.stem)
        }
        if value == "next":
            number = max((self._chapter_number(item) for item in chapter_ids), default=0) + 1
            value = f"ch_{number:03d}"
        elif value == "latest" or (latest and not value):
            value = max(chapter_ids, key=self._chapter_number) if chapter_ids else "ch_001"
        if not re.fullmatch(r"ch_\d+", value):
            raise NovelServiceError("章节 ID 必须形如 ch_001", code="INVALID_INPUT")
        return value

    def _load_config(self) -> dict[str, Any]:
        if not self.config_path.exists():
            raise NovelServiceError("未找到 novel_config.yaml", code="INVALID_PROJECT")
        try:
            data = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError) as exc:
            raise NovelServiceError(f"项目配置无法读取: {exc}", code="INVALID_PROJECT") from exc
        return data if isinstance(data, dict) else {}

    def _validate_source_id(self, source_id: str) -> str:
        value = str(source_id or "").strip()
        if not value or not re.fullmatch(r"[\w.-]{1,64}", value) or ".." in value:
            raise NovelServiceError(
                "来源 ID 只能包含字母、数字、中文、点、横线或下划线",
                code="INVALID_INPUT",
            )
        return value

    def _require_source_pack(self, source_id: str) -> Path:
        source_root = self.novel_root / "data" / "sources" / source_id
        if not source_root.is_dir():
            raise NovelServiceError("来源包不存在", code="NOT_FOUND")
        return source_root

    @staticmethod
    def _positive_int(value: Any) -> int:
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            return 0
        return parsed if parsed > 0 else 0

    @staticmethod
    def _chapter_number(chapter_id: str) -> int:
        match = re.search(r"(\d+)", chapter_id)
        return int(match.group(1)) if match else 0

    @staticmethod
    def _ensure_ok(result: dict[str, Any], *, fallback: str) -> None:
        if result.get("ok"):
            return
        raise NovelServiceError(
            str(result.get("error") or fallback),
            code=str(result.get("code") or "OPERATION_FAILED"),
        )

    @staticmethod
    def _default_writer_executor(root: Path, args: dict[str, Any]) -> dict[str, Any]:
        from tools.chapter_pipeline import execute_write_chapter

        result: dict[str, Any] = execute_write_chapter(root, args)
        return result

    @staticmethod
    def _default_review_executor(root: Path, args: dict[str, Any]) -> dict[str, Any]:
        from tools.chapter_pipeline import execute_review_chapter

        result: dict[str, Any] = execute_review_chapter(root, args)
        return result

    @staticmethod
    def _default_source_executor(root: Path, args: dict[str, Any]) -> dict[str, Any]:
        from tools.source_pack import SourcePackService

        config = yaml.safe_load((root / "novel_config.yaml").read_text(encoding="utf-8")) or {}
        result: dict[str, Any] = SourcePackService(root, str(config.get("novel_id") or "")).extract(
            str(args["source_id"]),
            Path(str(args["source_file"])),
            focus=str(args.get("focus") or "style"),
            chunk_size=int(args.get("chunk_size") or 30000),
        )
        return result

    def _record_write_lifecycle(self, chapter_id: str, result: dict[str, Any]) -> None:
        from tools.workflow_scheduler import WorkflowScheduler

        scheduler = WorkflowScheduler(self.project_root, self.novel_id)
        workflow = scheduler.load_or_create(chapter_id)
        statuses = {stage.name: stage.status for stage in workflow.stages}
        if statuses.get("context_assembly") != "completed":
            scheduler.start_stage(workflow, "context_assembly")
            scheduler.complete_stage(
                workflow,
                "context_assembly",
                message="canonical context assembled",
                data={"chapter_id": chapter_id},
            )
        if statuses.get("writing") != "completed":
            scheduler.start_stage(workflow, "writing")
            scheduler.complete_stage(
                workflow,
                "writing",
                message="chapter committed",
                data={"draft_path": str(result.get("draft_path") or "")},
            )
        self._sync_book_state(
            chapter_id,
            review_passed=None,
            action_prefix="application_write",
        )

    def _record_review_lifecycle(self, chapter_id: str, result: dict[str, Any]) -> None:
        from tools.review_store import (
            ReviewStore,
            issue_review_severity,
            review_is_deliverable,
        )
        from tools.workflow_scheduler import WorkflowScheduler

        store = ReviewStore(self.project_root, self.novel_id)
        current_revision = store._source_revision(chapter_id)
        deliverable = review_is_deliverable(result, current_source_revision=current_revision)
        scheduler = WorkflowScheduler(self.project_root, self.novel_id)
        workflow = scheduler.load_or_create(chapter_id)
        errors: list[str] = []
        warnings: list[str] = []
        for issue in result.get("issue_details", []):
            if not isinstance(issue, dict):
                continue
            description = str(issue.get("description") or "").strip()
            if not description:
                continue
            if issue_review_severity(issue) == "critical":
                errors.append(description)
            else:
                warnings.append(description)
        scheduler.start_stage(workflow, "review")
        scheduler.complete_stage(
            workflow,
            "review",
            message="chapter reviewed via application service",
            data={
                "passed": deliverable,
                "errors": errors,
                "warnings": warnings,
            },
        )
        self._sync_book_state(
            chapter_id,
            review_passed=deliverable,
            action_prefix="application_review",
        )

    def _sync_book_state(
        self,
        chapter_id: str,
        *,
        review_passed: bool | None,
        action_prefix: str,
    ) -> None:
        from tools.agent.book_state import BookStage, BookStateStore

        store = BookStateStore(self.project_root, self.novel_id)
        state = store.load_or_create()
        if self._chapter_number(chapter_id) >= self._chapter_number(state.current_chapter):
            state.current_chapter = chapter_id
        if review_passed is None:
            state.stage = BookStage.REVIEW_AND_REVISE
            state.blocking_reason = "review_not_run"
            state.last_agent_action = f"{action_prefix}_pending_review"
        elif review_passed:
            state.stage = BookStage.CHAPTER_PREFLIGHT
            state.blocking_reason = ""
            state.last_agent_action = f"{action_prefix}_review_passed"
        else:
            state.stage = BookStage.REVIEW_AND_REVISE
            state.blocking_reason = "review_revision_requested"
            state.last_agent_action = f"{action_prefix}_review_failed"
        store.save(state)
