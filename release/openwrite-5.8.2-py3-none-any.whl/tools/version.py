"""Single runtime version source for OpenWrite entry points."""

__version__ = "5.8.2"
