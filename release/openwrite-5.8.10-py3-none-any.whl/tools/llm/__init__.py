"""LLM 客户端模块

核心 LLM 封装能力：
- 统一接口支持 OpenAI / Anthropic / 自定义
- 流式输出监控
- 流失败自动降级为同步
- 人性化错误处理
"""

from .client import LLMClient, LLMConfig, LLMResponse, Message, ToolCallResponse
from .context import ContextBudgetPlan, ContextBudgetPolicy
from .errors import (
    APIError,
    AuthenticationError,
    InvalidRequestError,
    LLMTimeoutError,
    LLMWrappedError,
    NetworkError,
    RateLimitError,
)

__all__ = [
    "LLMClient",
    "LLMConfig",
    "LLMResponse",
    "ToolCallResponse",
    "Message",
    "ContextBudgetPlan",
    "ContextBudgetPolicy",
    "LLMWrappedError",
    "APIError",
    "AuthenticationError",
    "RateLimitError",
    "InvalidRequestError",
    "NetworkError",
    "LLMTimeoutError",
]
