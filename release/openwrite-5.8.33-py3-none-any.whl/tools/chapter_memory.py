"""Persistent chapter memory used by long-form context assembly."""

from __future__ import annotations

import hashlib
import logging
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger("tools.chapter_memory")


class ChapterMemoryStore:
    def __init__(self, project_root: Path, novel_id: str):
        self.project_root = Path(project_root).resolve()
        self.novel_id = novel_id
        self.memory_dir = (
            self.project_root
            / "data"
            / "novels"
            / novel_id
            / "data"
            / "memory"
            / "chapters"
        )

    def save(
        self,
        *,
        chapter_id: str,
        title: str,
        summary: str,
        word_count: int,
        observations: str = "",
        token_usage: dict[str, Any] | None = None,
        source_revision: str = "",
        acceptance_operation_id: str = "",
    ) -> Path:
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        path = self.path_for(chapter_id)
        payload = {
            "chapter_id": chapter_id,
            "title": title.strip(),
            "summary": summary.strip(),
            "word_count": max(0, int(word_count)),
            "observations": observations.strip(),
            "token_usage": dict(token_usage or {}),
            "source_revision": str(source_revision or self._manuscript_revision(chapter_id)),
            "acceptance_operation_id": str(acceptance_operation_id or ""),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        content = yaml.safe_dump(payload, allow_unicode=True, sort_keys=False)
        self._atomic_write(path, content)
        return path

    def _inspect_acceptance(self) -> dict[str, dict[str, Any]]:
        """Acceptance heads keyed by chapter id.

        `inspect()` reads and hashes every chapter file, so calling it once per
        record made a book of n chapters cost O(n^2) file reads - measured 0.6 s
        at 120 chapters and roughly 250 000 reads at 500, paid on every generation
        and every desk load. Bulk callers pass the result down so it is computed
        once per call; a single `load()` still computes it fresh, because a rewrite
        invalidates the acceptance state within a store's lifetime.
        """
        from tools.manuscript_acceptance import ManuscriptAcceptanceService

        try:
            inspection = ManuscriptAcceptanceService(self.project_root, self.novel_id).inspect()
        except Exception as exc:
            logger.warning("Acceptance inspection unavailable: %s", exc)
            return {}
        return {
            str(item.get("chapter_id") or ""): item
            for item in inspection.get("chapters", [])
            if isinstance(item, dict)
        }

    def load(
        self,
        chapter_id: str,
        acceptance_heads: dict[str, dict[str, Any]] | None = None,
    ) -> dict[str, Any] | None:
        path = self.path_for(chapter_id)
        if not path.is_file():
            return None
        try:
            data = yaml.safe_load(path.read_bytes().decode("utf-8")) or {}
        except (OSError, yaml.YAMLError) as exc:
            # A truncated record used to be swallowed into `None`, which is
            # indistinguishable from "no memory yet" — the chapter's summary then
            # vanished from every later prompt with no signal at all.
            logger.warning("Chapter memory %s is unreadable: %s", path.name, exc)
            return {"freshness_status": "corrupt", "chapter_id": chapter_id}
        if not isinstance(data, dict):
            logger.warning("Chapter memory %s is not a mapping", path.name)
            return {"freshness_status": "corrupt", "chapter_id": chapter_id}
        source_revision = str(data.get("source_revision") or "")
        current_revision = self._manuscript_revision(chapter_id)
        if source_revision and current_revision and source_revision == current_revision:
            freshness = "current"
        elif source_revision and current_revision:
            freshness = "stale"
        else:
            freshness = "unknown"
        # A matching file SHA is necessary but not sufficient while an earlier
        # chapter acceptance is replaying downstream facts. The acceptance
        # head is the causal gate for summaries used in later prompts.
        try:
            head = None
            if (acceptance_heads is not None):
                head = acceptance_heads.get(chapter_id)
            else:
                inspection = self._inspect_acceptance()
                head = inspection.get(chapter_id)
            if isinstance(head, dict) and (
                head.get("status") != "current"
                or head.get("facts_revision") != current_revision
            ):
                freshness = "stale"
        except Exception:
            pass
        return {
            **data,
            "source_revision": source_revision,
            "current_source_revision": current_revision,
            "freshness_status": freshness,
        }

    def list_before(self, chapter_id: str) -> list[dict[str, Any]]:
        target = self._chapter_number(chapter_id)
        records: list[dict[str, Any]] = []
        if not self.memory_dir.exists():
            return records
        # One acceptance inspect for the whole sweep: `load()` would otherwise run
        # one per chapter, which is O(n^2) in the chapter count.
        heads = self._inspect_acceptance()
        for path in self.memory_dir.glob("ch_*.yaml"):
            # A stray name (`ch_old.yaml`, a hand-renamed file) must be skipped,
            # not fatal: `load()` raises for anything that is not `ch_<digits>`,
            # and one such file used to break every context build for the novel.
            if not re.fullmatch(r"ch_\d+", path.stem):
                continue
            number = self._chapter_number(path.stem)
            if target and number >= target:
                continue
            record = self.load(path.stem, heads)
            if record and record.get("freshness_status") == "current":
                records.append(record)
        return sorted(
            records,
            key=lambda item: self._chapter_number(str(item.get("chapter_id", ""))),
        )

    def render_context(self, chapter_id: str, *, max_chars: int = 4000) -> str:
        records = self.list_before(chapter_id)
        selected: list[str] = []
        used = 0
        for record in reversed(records):
            summary = str(record.get("summary") or "").strip()
            if not summary:
                observations = str(record.get("observations") or "").strip()
                summary = observations[:500]
            if not summary:
                continue
            chapter = str(record.get("chapter_id") or "")
            title = str(record.get("title") or chapter)
            entry = f"- {chapter}《{title}》：{summary}"
            if selected and used + len(entry) > max_chars:
                break
            selected.append(entry[:max_chars])
            used += len(entry)
        selected.reverse()
        return "\n".join(selected)

    def usage_totals(self) -> dict[str, int]:
        totals = {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        }
        if not self.memory_dir.exists():
            return totals
        heads = self._inspect_acceptance()
        for path in self.memory_dir.glob("ch_*.yaml"):
            if not re.fullmatch(r"ch_\d+", path.stem):
                continue
            record = self.load(path.stem, heads) or {}
            usage = record.get("token_usage", {})
            if not isinstance(usage, dict):
                continue
            for key in totals:
                value = usage.get(key, 0)
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    totals[key] += int(value)
        return totals

    def path_for(self, chapter_id: str) -> Path:
        safe = chapter_id if re.fullmatch(r"ch_\d+", chapter_id) else ""
        if not safe:
            raise ValueError(f"无效章节 ID: {chapter_id}")
        return self.memory_dir / f"{safe}.yaml"

    def delete(self, chapter_id: str) -> None:
        self.path_for(chapter_id).unlink(missing_ok=True)

    def _manuscript_revision(self, chapter_id: str) -> str:
        manuscript = (
            self.project_root
            / "data"
            / "novels"
            / self.novel_id
            / "data"
            / "manuscript"
        )
        matches = list(manuscript.rglob(f"{chapter_id}.md")) if manuscript.is_dir() else []
        if len(matches) != 1 or not matches[0].is_file():
            return ""
        try:
            content = matches[0].read_bytes().decode("utf-8")
        except OSError:
            return ""
        return "sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest()

    @staticmethod
    def _chapter_number(chapter_id: str) -> int:
        match = re.search(r"(\d+)", chapter_id)
        return int(match.group(1)) if match else 0

    @staticmethod
    def _atomic_write(path: Path, content: str) -> None:
        # Delegate to the shared writer: it cleans up its temporary file in a
        # finally block, so a failed replace cannot leak one.
        from tools.file_ops import atomic_write

        atomic_write(path, content)
